from playsound import playsound
playsound('eyes.mp3')